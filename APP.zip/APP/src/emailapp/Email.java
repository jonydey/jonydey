package emailapp;

import java.util.Scanner;

public class Email {
private String firstName;
private String lastName;
private String passWord;
private String department;
private int mailboxCapacity=500;
private String alternalemail;
private int defaultPassLength=8;
private String email;
//constructor to receive the firstname and lastname

public Email(String firstName, String lastName) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	System.out.println("Email created:"+this.firstName+ " " +this.lastName);
	this.department= setDepartment();
	System.out.println("Department:"+this.department);
	this.passWord= randomPass(defaultPassLength);
	
	email=firstName.toLowerCase()+lastName.toLowerCase()+"xcompany@gmai.com";
}

// call a method asking for a department
private String setDepartment() {
	System.out.println("Department codes: \n 1 for sales\n2 for developement\n3 for Accounting\n4 for none\n Enter department code:");
Scanner s = new Scanner(System.in);
int depart = s.nextInt();
if(depart==1) {return "Sales";}
else if(depart==2) {return "Development";}
else if(depart==3) {return "Accounting";}
else {return "None";}	
}
private String randomPass(int length) {
	String passWord="ABCDEFGHIJKLMNOPQRSTWXYZ$�*()";
	char[] ch = new char[length];
	for(int i=0;i<length;i++) {
		int rand = (int) (Math.random()*passWord.length());
		ch[i] = passWord.charAt(rand);
	}
	return new String (ch);
}

public String getPassWord() {
	return passWord;
}

public void setPassWord(String passWord) {
	this.passWord = passWord;
	
}

public int getMailboxCapacity() {
	return mailboxCapacity;
}

public void setMailboxCapacity(int mailboxCapacity) {
	this.mailboxCapacity = mailboxCapacity;
}

public String getAlternalemail() {
	return alternalemail;
}

public void setAlternalemail(String alternalemail) {
	this.alternalemail = alternalemail;
}

public String showInfo() {
	return "Display Name" + firstName +" "+lastName+
	       "\nCompany Email:"+email+
	       "\nMailbox Capacity:"+mailboxCapacity+"mb"+
	       "\nPassword:"+passWord;
	       
}

}
